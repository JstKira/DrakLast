document.addEventListener("DOMContentLoaded", function() {
    console.log("الموقع جاهز!");
});
